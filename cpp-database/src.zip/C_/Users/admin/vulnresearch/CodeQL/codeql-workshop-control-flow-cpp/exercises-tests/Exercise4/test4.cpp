void successors(int n) {
  if (n > 5) {
    if (n > 10) {
    }
  }

  if (n == 5) {
  }
}
